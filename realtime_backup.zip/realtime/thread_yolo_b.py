# ─────────────────────────────────────────────
# thread_yolo_b.py  –  Thread-3
# Heavy-duty batched YOLO inference on alternate frames in DENSE mode.
# Makes NO state decisions — purely outputs detections.
# ─────────────────────────────────────────────

import time
import queue
import sys
import os
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from inference_video_batch import predict_frames_batch

import shared_state as state
from config import YOLO_B_BATCH_SIZE


def _extract_detections(result):
    """Extract boxes, classes, confidences from a YOLO result object."""
    if result is None or result.boxes is None or len(result.boxes) == 0:
        return [], [], []
    return (
        result.boxes.xyxy.cpu().numpy(),
        result.boxes.cls.cpu().numpy(),
        result.boxes.conf.cpu().numpy(),
    )

# Max seconds to keep collecting frames into one batch after the first arrives.
# At 25fps every-2nd-frame = 12.5fps for YOLO-B → 8 frames take ~640ms.
# Set this just below that so we don't over-wait, but long enough to accumulate.
BATCH_COLLECT_TIMEOUT  = 0.5   # seconds
INTER_FRAME_WAIT       = 0.02  # 20ms poll between frames while collecting


def _flush_batch(model_b, pending: list) -> None:
    """
    Run YOLO-B on a collected batch and print results.
    Output hook: replace print with downstream consumer as needed.

    Args:
        model_b: loaded YOLO model instance (heavy)
        pending:  list of (frame_id, frame) tuples
    """
    frame_ids  = [fid for fid, _ in pending]
    frames     = [f   for _,   f in pending]
    batch_size = len(frames)

    t0      = time.time()
    results = predict_frames_batch(model_b, frames)
    infer_ms      = (time.time() - t0) * 1000
    per_frame_ms  = infer_ms / batch_size

    print(f"[YOLO-B] batch={batch_size}  infer={infer_ms:.1f}ms  "
          f"per_frame={per_frame_ms:.1f}ms  fps={1000/per_frame_ms:.1f}")

    for fid, result in zip(frame_ids, results):
        det_count = (
            len(result.boxes)
            if result is not None and result.boxes is not None
            else 0
        )
        boxes, classes, confidences = _extract_detections(result)
        try:
            state.results_queue.put_nowait({
                'frame_id'    : fid,
                'source'      : 'YOLO-B',
                'det_count'   : det_count,
                'boxes'       : boxes,
                'classes'     : classes,
                'confidences' : confidences,
                'infer_ms'    : per_frame_ms,
            })
        except queue.Full:
            pass   # drop silently if consumer is not keeping up

        print(f"[YOLO-B] frame={fid:5d}  detections={det_count}")


def thread_yolo_b(model_b) -> None:
    """
    Thread-3 entry point.

    Accumulates frames from yolo_b_queue into batches of YOLO_B_BATCH_SIZE,
    then runs YOLO-B inference. Also flushes partial batches when the queue
    goes idle to avoid stale frames sitting in the buffer.

    Args:
        model_b: loaded YOLO model instance (heavy)
    """
    while not state.stop_event.is_set():
        pending: list = []

        # ── Step 1: block until the first frame arrives ────────────────────
        try:
            first = state.yolo_b_queue.get(timeout=1.0)
            pending.append(first)
        except queue.Empty:
            continue   # nothing yet, loop back and check stop_event

        # ── Step 2: greedily collect more frames up to batch size ──────────
        # Stop when: batch is full  OR  queue stays idle  OR  deadline hit.
        deadline = time.time() + BATCH_COLLECT_TIMEOUT
        while len(pending) < YOLO_B_BATCH_SIZE and time.time() < deadline:
            try:
                item = state.yolo_b_queue.get(timeout=INTER_FRAME_WAIT)
                pending.append(item)
            except queue.Empty:
                # Queue went idle — flush what we have rather than wait for deadline
                break

        # ── Step 3: flush the collected batch ──────────────────────────────
        print(f"[YOLO-B] Flushing batch of {len(pending)} frames "
              f"(target={YOLO_B_BATCH_SIZE})")
        _flush_batch(model_b, pending)

    # Drain any remaining frames on shutdown
    remaining: list = []
    while True:
        try:
            remaining.append(state.yolo_b_queue.get_nowait())
        except queue.Empty:
            break
    if remaining:
        print(f"[YOLO-B] Flushing {len(remaining)} remaining frames on shutdown.")
        _flush_batch(model_b, remaining)

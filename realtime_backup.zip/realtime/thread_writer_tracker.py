# ─────────────────────────────────────────────
# thread_writer_tracker.py  –  Thread-4 (merged writer + tracker)
#
# Consumes results_queue and does two things in one pass:
#   1. Writes ALL detections (YOLO-A + YOLO-B) to detections_<ts>.csv
#   2. For YOLO-B only: runs per-class IoU tracking (skips class 0)
#      - Expired tracks → flushed_tracks_<ts>.jsonl (one JSON per track, on eviction)
#
# Tracker rules:
#   - Directionality: only match detections with centre-Y >= track's last centre-Y
#                     (object must be moving downward in the frame)
#   - Containment gate: bbox containment >= 0.7 required before IoU score is used
#   - Age gate: track is flushed after max_track_age frames of no observation
# ─────────────────────────────────────────────

import csv
import json
import queue
import time
import sys
import os
import numpy as np
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Tuple

import shared_state as state


# ══════════════════════════════════════════════════════════════════════════════
# CustomFeatureTracker — IoU-only matching with directional constraint
# ══════════════════════════════════════════════════════════════════════════════

class CustomFeatureTracker:
    """
    Per-class containment tracker.

    Matching rules (all must pass for a valid match):
      1. Bbox containment >= 0.5  (spatial overlap gate + score)

    Tracks are flushed after max_track_age consecutive frames with no match.
    Flushed track data (full history) is returned by update() for the caller
    to persist to the flushed_tracks CSV.
    """

    def __init__(self, similarity_threshold: float = 0.2,
                 max_track_age: int = 3, max_tracks: int = -1,
                 id_counter: list = None):
        self.similarity_threshold = similarity_threshold
        self.max_track_age        = max_track_age
        self.max_tracks           = max_tracks
        self.tracks               = {}   # track_id -> track_data
        # Shared mutable counter — pass the same [0] list to all class trackers
        # so track IDs are globally unique across all classes.
        self._id_counter = id_counter if id_counter is not None else [0]

    def update(self, detections: List[Dict], frame_id: int
               ) -> Tuple[List[Dict], Dict[int, Dict]]:
        """
        Update tracker with new detections for one frame.

        Args:
            detections: list of dicts with keys: bbox, confidence, class_id
            frame_id:   current frame number

        Returns:
            (tracked, flushed)
            tracked – list of dicts with track_id added (active this frame)
            flushed – dict of {track_id: track_data} for evicted tracks
        """
        if not detections:
            flushed = self._cleanup_old_tracks(frame_id)
            return [], flushed

        similarity_matrix = self._calculate_similarity_matrix(detections)
        assignments       = self._assign_tracks(similarity_matrix)
        tracked           = self._update_tracks(assignments, detections, frame_id)
        flushed           = self._cleanup_old_tracks(frame_id)
        return tracked, flushed

    # ── Similarity ────────────────────────────────────────────────────────────

    def _calculate_similarity_matrix(self, detections: List[Dict]) -> np.ndarray:
        if not self.tracks:
            return np.zeros((len(detections), 0))

        n_det  = len(detections)
        n_trk  = len(self.tracks)
        matrix = np.zeros((n_det, n_trk))

        for d_idx, det in enumerate(detections):
            for t_idx, (track_id, track_data) in enumerate(self.tracks.items()):
                if not track_data['history']:
                    continue
                latest = track_data['history'][-1]

                # ── Rule 1: containment gate + score ─────────────────────────
                containment = self._bbox_containment(det['bbox'], latest['bbox'])
                if containment < 0.5:
                    matrix[d_idx, t_idx] = -1.0
                else:
                    matrix[d_idx, t_idx] = containment

        return matrix

    def _bbox_containment(self, bbox1: List, bbox2: List) -> float:
        """
        Symmetric containment: max(inter/area1, inter/area2).
        Returns the higher of the two one-sided containment values so that
        growing objects (approaching camera) still pass the gate even when
        the new detection bbox is much larger than the track's last bbox.
        """
        if len(bbox1) < 4 or len(bbox2) < 4:
            return 0.0
        x1_1, y1_1, x2_1, y2_1 = bbox1[:4]
        x1_2, y1_2, x2_2, y2_2 = bbox2[:4]
        xi1, yi1 = max(x1_1, x1_2), max(y1_1, y1_2)
        xi2, yi2 = min(x2_1, x2_2), min(y2_1, y2_2)
        if xi2 <= xi1 or yi2 <= yi1:
            return 0.0
        inter = (xi2 - xi1) * (yi2 - yi1)
        area1 = (x2_1 - x1_1) * (y2_1 - y1_1)
        area2 = (x2_2 - x1_2) * (y2_2 - y1_2)
        c1 = inter / area1 if area1 > 0 else 0.0
        c2 = inter / area2 if area2 > 0 else 0.0
        return max(c1, c2)

    def _bbox_iou(self, bbox1: List, bbox2: List) -> float:
        """Standard IoU between two boxes."""
        if len(bbox1) < 4 or len(bbox2) < 4:
            return 0.0
        x1_1, y1_1, x2_1, y2_1 = bbox1[:4]
        x1_2, y1_2, x2_2, y2_2 = bbox2[:4]
        xi1, yi1 = max(x1_1, x1_2), max(y1_1, y1_2)
        xi2, yi2 = min(x2_1, x2_2), min(y2_1, y2_2)
        if xi2 <= xi1 or yi2 <= yi1:
            return 0.0
        inter = (xi2 - xi1) * (yi2 - yi1)
        area1 = (x2_1 - x1_1) * (y2_1 - y1_1)
        area2 = (x2_2 - x1_2) * (y2_2 - y1_2)
        union = area1 + area2 - inter
        return inter / union if union > 0 else 0.0

    # ── Assignment ────────────────────────────────────────────────────────────

    def _assign_tracks(self, matrix: np.ndarray) -> List[Tuple[int, int]]:
        if matrix.size == 0:
            return []
        pairs = []
        for d_idx in range(matrix.shape[0]):
            for t_idx in range(matrix.shape[1]):
                score = matrix[d_idx, t_idx]
                if score >= self.similarity_threshold:
                    pairs.append((score, d_idx, t_idx))
        pairs.sort(reverse=True)
        used_d, used_t = set(), set()
        assignments = []
        for score, d_idx, t_idx in pairs:
            if d_idx not in used_d and t_idx not in used_t:
                assignments.append((d_idx, t_idx))
                used_d.add(d_idx)
                used_t.add(t_idx)
        return assignments

    # ── Track update ──────────────────────────────────────────────────────────

    def _update_tracks(self, assignments: List[Tuple[int, int]],
                       detections: List[Dict], frame_id: int) -> List[Dict]:
        tracked = []
        track_id_list = list(self.tracks.keys())

        for d_idx, t_idx in assignments:
            track_id = track_id_list[t_idx]
            det      = detections[d_idx]
            hist = self.tracks[track_id]['history']
            hist.append({
                'frame_id'  : frame_id,
                'bbox'      : det['bbox'],
                'confidence': det['confidence'],
            })
            # History grows unbounded until the track is flushed/pruned
            result = det.copy()
            result['track_id'] = track_id
            tracked.append(result)

        assigned_d = {d for d, _ in assignments}
        for d_idx, det in enumerate(detections):
            if d_idx not in assigned_d:
                if det.get('confidence', 0.0) < 0.5:
                    continue
                track_id = self._id_counter[0]
                self._id_counter[0] += 1
                self.tracks[track_id] = {'history': [{
                    'frame_id'  : frame_id,
                    'bbox'      : det['bbox'],
                    'confidence': det['confidence'],
                }]}
                result = det.copy()
                result['track_id'] = track_id
                tracked.append(result)

        return tracked

    def _cleanup_old_tracks(self, current_frame: int) -> Dict[int, Dict]:
        """
        Remove tracks older than max_track_age frames.

        Returns:
            dict of {track_id: track_data} for every evicted track,
            so the caller can persist them to the flushed-tracks CSV.
        """
        to_remove = [
            tid for tid, tdata in self.tracks.items()
            if tdata['history'] and
               current_frame - tdata['history'][-1]['frame_id'] > self.max_track_age
        ]
        flushed = {}
        for tid in to_remove:
            flushed[tid] = self.tracks.pop(tid)
        return flushed

    def flush_all(self) -> Dict[int, Dict]:
        """Evict every remaining active track (call at pipeline shutdown)."""
        flushed = dict(self.tracks)
        self.tracks.clear()
        return flushed


# ══════════════════════════════════════════════════════════════════════════════
# Thread entry point
# ══════════════════════════════════════════════════════════════════════════════

def thread_writer_tracker(output_dir: str = "results", video_stem: str = "") -> None:
    """
    Thread-4 entry point (merged writer + tracker).

    Reads from state.results_queue:
      - ALL items  → detections_<ts>.csv     (raw detections, all sources)
      - YOLO-B only, class != 0:
          active frames  → tracked_<ts>.csv        (track_id assigned)
          evicted tracks → flushed_tracks_<ts>.csv (full per-track history)

    Output files (all in output_dir):
      detections_<ts>.csv
          timestamp, frame_id, source, det_index, x1, y1, x2, y2,
          class_id, confidence, infer_ms

      flushed_tracks_<ts>.jsonl  ← one JSON object per line, one per expired track
          {
            "track_id":        int,
            "class_id":        int,
            "length":          int,          # number of frames track was alive
            "first_frame":     int,
            "last_frame":      int,
            "flush_timestamp": str,
            "history": [
              {"frame_id": int, "bbox": [x1,y1,x2,y2], "confidence": float},
              ...
            ]
          }
    """
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    ts     = datetime.now().strftime("%Y%m%d_%H%M%S")
    prefix = f"{video_stem}_" if video_stem else ""

    det_csv_path      = Path(output_dir) / f"detections_{prefix}{ts}.csv"
    flushed_json_path = Path(output_dir) / f"flushed_tracks_{prefix}{ts}.jsonl"

    print(f"[Writer] Raw CSV      : {det_csv_path}")
    print(f"[Writer] Flushed JSONL: {flushed_json_path}")

    # Per-class tracker instances (class 0 excluded)
    class_trackers: Dict[int, CustomFeatureTracker] = {}
    # Single shared counter so track IDs are globally unique across all classes
    global_track_id = [0]

    rows_written = 0

    with open(det_csv_path,      "w", newline="") as det_f, \
         open(flushed_json_path, "w")             as flu_f:

        det_writer = csv.writer(det_f)

        det_writer.writerow([
            "timestamp", "frame_id", "source",
            "det_index", "x1", "y1", "x2", "y2",
            "class_id", "confidence", "infer_ms"
        ])

        def _write_flushed(flushed: Dict[int, Dict], cls_id: int) -> None:
            """
            Write each expired track as one JSON object (one line) to the JSONL file.
            Fields:
              track_id, class_id, length, first_frame, last_frame,
              flush_timestamp, history[{frame_id, bbox, confidence}]
            """
            flush_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
            for track_id, track_data in flushed.items():
                hist = track_data['history']
                record = {
                    "track_id"       : track_id,
                    "class_id"       : cls_id,
                    "length"         : len(hist),
                    "first_frame"    : hist[0]['frame_id']  if hist else None,
                    "last_frame"     : hist[-1]['frame_id'] if hist else None,
                    "flush_timestamp": flush_ts,
                    "history"        : [
                        {
                            "frame_id"  : h['frame_id'],
                            "bbox"      : [round(v, 1) for v in h['bbox'][:4]],
                            "confidence": round(h['confidence'], 4),
                        }
                        for h in hist
                    ],
                    "plate_history"  : track_data.get('plate_history', []),
                }
                flu_f.write(json.dumps(record) + "\n")
                print(f"[Tracker] Flushed track {track_id} class={cls_id} "
                      f"length={len(hist)} frames "
                      f"frames {record['first_frame']}→{record['last_frame']}")

        # ── Main loop ─────────────────────────────────────────────────────────
        while not state.stop_event.is_set() or not state.results_queue.empty():
            try:
                item = state.results_queue.get(timeout=0.5)
            except queue.Empty:
                continue

            ts_now   = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
            frame_id = item["frame_id"]
            source   = item["source"]
            infer_ms = item["infer_ms"]
            boxes    = item["boxes"]
            classes  = item["classes"]
            confs    = item["confidences"]

            # ── 1. Raw detections CSV (all sources) ───────────────────────────
            if item["det_count"] == 0:
                det_writer.writerow([
                    ts_now, frame_id, source,
                    -1, "", "", "", "", "", "", f"{infer_ms:.2f}"
                ])
            else:
                for idx, (box, cls, conf) in enumerate(zip(boxes, classes, confs)):
                    x1, y1, x2, y2 = box
                    det_writer.writerow([
                        ts_now, frame_id, source,
                        idx,
                        f"{x1:.1f}", f"{y1:.1f}", f"{x2:.1f}", f"{y2:.1f}",
                        int(cls), f"{conf:.4f}", f"{infer_ms:.2f}"
                    ])

            # ── 2. Tracking (YOLO-B only) ─────────────────────────────────────
            if source == "YOLO-B":
                # Group detections by class; collect number plates separately
                by_class: Dict[int, List[Dict]] = {}
                plates: List[Dict] = []
                for box, cls, conf in zip(boxes, classes, confs):
                    cls_id = int(cls)
                    if cls_id == 0:
                        plates.append({
                            'bbox'      : box.tolist() if hasattr(box, 'tolist') else list(box),
                            'confidence': float(conf),
                        })
                        continue
                    by_class.setdefault(cls_id, []).append({
                        'bbox'      : box.tolist() if hasattr(box, 'tolist') else list(box),
                        'confidence': float(conf),
                        'class_id'  : cls_id,
                    })

                assigned_plates: set = set()   # plate indices already matched

                for cls_id, dets in by_class.items():
                    if cls_id not in class_trackers:
                        class_trackers[cls_id] = CustomFeatureTracker(
                            similarity_threshold=0.2,
                            max_track_age=3,
                            id_counter=global_track_id,
                        )
                        print(f"[Tracker] New tracker for class {cls_id}")

                    tracked, flushed = class_trackers[cls_id].update(dets, frame_id)

                    # Write any tracks evicted by age
                    if flushed:
                        _write_flushed(flushed, cls_id)

                    # Associate unmatched plates to live tracks of this class.
                    # Step 1: direct intersection — assign if plate is >= 50% inside vehicle bbox.
                    # Step 2: fallback Y-distance — if no intersection match, assign to the
                    #         closest track whose Y gap to the plate is < 100 px.
                    for p_idx, plate in enumerate(plates):
                        if p_idx in assigned_plates:
                            continue
                        pb         = plate['bbox']
                        px1, py1, px2, py2 = pb[0], pb[1], pb[2], pb[3]
                        plate_area = max((px2 - px1) * (py2 - py1), 1e-6)

                        best_tid_intersect, best_contain  = None, 0.0
                        best_tid_ydist,     best_ydist    = None, float('inf')

                        for track_id, track_data in class_trackers[cls_id].tracks.items():
                            if not track_data['history']:
                                continue
                            vb = track_data['history'][-1]['bbox']
                            vx1, vy1, vx2, vy2 = vb[0], vb[1], vb[2], vb[3]

                            # Step 1: containment of plate inside vehicle
                            xi1 = max(px1, vx1);  yi1 = max(py1, vy1)
                            xi2 = min(px2, vx2);  yi2 = min(py2, vy2)
                            if xi2 > xi1 and yi2 > yi1:
                                contain = (xi2 - xi1) * (yi2 - yi1) / plate_area
                                if contain > best_contain:
                                    best_contain, best_tid_intersect = contain, track_id

                            # Step 2: Y distance fallback — gap between vehicle ymax and plate ymin
                            y_dist = abs(py1 - vy2)
                            if y_dist < best_ydist:
                                best_ydist, best_tid_ydist = y_dist, track_id

                        # Resolve: intersection wins; Y-distance is fallback
                        if best_tid_intersect is not None and best_contain >= 0.5:
                            winner = best_tid_intersect
                        elif best_tid_ydist is not None and best_ydist < 100:
                            winner = best_tid_ydist
                        else:
                            winner = None

                        if winner is not None:
                            class_trackers[cls_id].tracks[winner] \
                                .setdefault('plate_history', []) \
                                .append({
                                    'frame_id'  : frame_id,
                                    'bbox'      : [round(v, 1) for v in pb[:4]],
                                    'confidence': round(plate['confidence'], 4),
                                })
                            assigned_plates.add(p_idx)

                # Age-out ALL class trackers, not just those with detections this frame
                for tid, t in class_trackers.items():
                    if tid not in by_class:
                        flushed_idle = t._cleanup_old_tracks(frame_id)
                        if flushed_idle:
                            _write_flushed(flushed_idle, tid)

            rows_written += 1
            if rows_written % 50 == 0:
                det_f.flush()
                flu_f.flush()

        # ── Pipeline ended: flush all remaining active tracks ─────────────────
        print("[Tracker] Pipeline done — flushing all remaining active tracks ...")
        for cls_id, tracker in class_trackers.items():
            remaining = tracker.flush_all()
            if remaining:
                _write_flushed(remaining, cls_id)

        det_f.flush()
        flu_f.flush()

    print(f"[Writer] Done — {rows_written} items processed.")
    print(f"[Writer] Output files:")
    print(f"         {det_csv_path}")
    print(f"         {flushed_json_path}")

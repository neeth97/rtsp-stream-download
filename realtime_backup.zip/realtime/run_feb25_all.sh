#!/bin/bash
# Run main.py for all feb25 videos (after S3 sync)
# Run from: /home/ubuntu/new_testing_code/realtime/

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VIDEO_DIR="/home/ubuntu/new_testing_code/yolo_dataset/videos/feb25"
MODEL="$SCRIPT_DIR/../yolo_dataset/runs/train3/weights/best.pt"
OUTPUT_DIR="$SCRIPT_DIR/results"

echo "========================================================"
echo "  Feb-25 batch processing"
echo "  Model : $MODEL"
echo "  Videos: $VIDEO_DIR"
echo "  Output: $OUTPUT_DIR"
echo "========================================================"

# Step 1: Sync remaining Cam 1 and all Cam 2 from S3
echo ""
echo "[sync] Syncing ANPR Cam 1 from S3 ..."
aws s3 sync "s3://metroinfrasys-images-gantry/02-25-2026+videos/ANPR Cam 1/" "$VIDEO_DIR/"
echo "[sync] Cam 1 done."

echo ""
echo "[sync] Syncing ANPR Cam 2 from S3 ..."
aws s3 sync "s3://metroinfrasys-images-gantry/02-25-2026+videos/ANPR Cam 2/" "$VIDEO_DIR/"
echo "[sync] Cam 2 done."

echo ""
echo "[sync] All videos synced."
ls "$VIDEO_DIR/" | wc -l
echo "files in $VIDEO_DIR"

# Step 2: Run main.py for each .mkv
VIDEOS=("$VIDEO_DIR"/*.mkv)
TOTAL=${#VIDEOS[@]}
echo ""
echo "========================================================"
echo "  Starting main.py for $TOTAL videos"
echo "========================================================"

COUNT=0
for VIDEO in "${VIDEOS[@]}"; do
    COUNT=$((COUNT + 1))
    STEM=$(basename "$VIDEO" .mkv)

    # Skip if results already exist (flushed_tracks JSONL present)
    if ls "$OUTPUT_DIR/flushed_tracks_${STEM}"_*.jsonl 1>/dev/null 2>&1; then
        echo ""
        echo "[$COUNT/$TOTAL] SKIP (results exist): $STEM"
        continue
    fi

    echo ""
    echo "[$COUNT/$TOTAL] Processing: $STEM"
    echo "  Started: $(date)"

    cd "$SCRIPT_DIR"
    python3 main.py \
        --model "$MODEL" \
        --video "$VIDEO" \
        --output "$OUTPUT_DIR"

    echo "  Finished: $(date)"
done

echo ""
echo "========================================================"
echo "  All $TOTAL videos processed."
echo "========================================================"

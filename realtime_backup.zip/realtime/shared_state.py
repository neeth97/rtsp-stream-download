# ─────────────────────────────────────────────
# shared_state.py  –  all shared state between threads
# ─────────────────────────────────────────────

import queue
import threading

# ── Mode ──────────────────────────────────────
mode             = "SPARSE"   # "SPARSE" | "DENSE"
mode_lock        = threading.Lock()

# ── Rolling frame buffer ───────────────────────
rolling_buffer   = {}         # frame_id (int) → frame (np.ndarray)
safe_clear_ptr   = 0          # frames with frame_id < this can be evicted
buffer_lock      = threading.Lock()

# ── Inter-thread queues ────────────────────────
# Each item: (frame_id: int, frame: np.ndarray)
yolo_a_queue     = queue.Queue(maxsize=200)
yolo_b_queue     = queue.Queue(maxsize=200)

# ── Detection results queue ────────────────────
# Each item: dict with keys:
#   frame_id    : int
#   source      : 'YOLO-A' | 'YOLO-B'
#   det_count   : int
#   boxes       : np.ndarray (N, 4) xyxy  or []
#   classes     : np.ndarray (N,)         or []
#   confidences : np.ndarray (N,)         or []
#   infer_ms    : float
results_queue    = queue.Queue(maxsize=500)

# ── Transition signals (Thread-2 → Thread-1) ──
signal_s2d       = threading.Event()   # SPARSE → DENSE
signal_d2s       = threading.Event()   # DENSE  → SPARSE

# Frame ID at which YOLO-A triggered SPARSE→DENSE
detected_at_frame = None               # guarded by mode_lock

# ── Graceful shutdown ──────────────────────────
stop_event       = threading.Event()

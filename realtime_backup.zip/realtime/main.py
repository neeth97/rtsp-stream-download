#!/usr/bin/env python3
# ─────────────────────────────────────────────
# main.py  –  entry point
# Loads models, opens video, launches Thread-1/2/3, handles shutdown.
# ─────────────────────────────────────────────

import sys
import os
import threading
import argparse
from pathlib import Path

import cv2
from ultralytics import YOLO

# Allow sibling imports (shared_state, config, thread_*)
sys.path.insert(0, os.path.dirname(__file__))
# Allow importing predict_frames_batch from parent directory
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import shared_state as state
from config import SIMULATE_FPS, EMPTY_COUNT_THRESH, YOLO_B_BATCH_SIZE
from thread_dispatcher    import thread_frame_dispatcher
from thread_yolo_a        import thread_yolo_a
from thread_yolo_b        import thread_yolo_b
from thread_writer_tracker import thread_writer_tracker


def run_adaptive(
    model_path: str,
    video_path: str,
    empty_thresh: int  = EMPTY_COUNT_THRESH,
    simulate_fps: float = SIMULATE_FPS,
    yolo_b_batch: int  = YOLO_B_BATCH_SIZE,
    output_dir: str    = "results",
) -> None:
    """
    Launch the adaptive SPARSE/DENSE inference pipeline.

    Args:
        model_path:   Path to YOLO weights (used for both YOLO-A and YOLO-B)
        video_path:   Path to input video file
        empty_thresh: Consecutive YOLO-A misses before exiting DENSE mode
        simulate_fps: Target FPS for Thread-1 real-time simulation
        yolo_b_batch: YOLO-B batch accumulation size
    """
    # Apply runtime config overrides
    import config as cfg
    cfg.EMPTY_COUNT_THRESH = empty_thresh
    cfg.SIMULATE_FPS       = simulate_fps
    cfg.YOLO_B_BATCH_SIZE  = yolo_b_batch

    print("=" * 70)
    print("Adaptive YOLO Inference Pipeline")
    print("=" * 70)
    print(f"  Model       : {model_path}")
    print(f"  Video       : {video_path}")
    print(f"  Simulate FPS: {simulate_fps}  (sleep budget = {1000/simulate_fps:.1f}ms/frame)")
    print(f"  Empty thresh: {empty_thresh} consecutive YOLO-A misses → SPARSE")
    print(f"  YOLO-B batch: {yolo_b_batch} frames")
    print("=" * 70)

    # ── Load models ────────────────────────────────────────────────────────
    print("\nLoading YOLO-A model ...")
    model_a = YOLO(model_path)
    print("Loading YOLO-B model ...")
    model_b = YOLO(model_path)   # separate instance; swap for a heavier model if needed
    print("Models loaded.\n")

    # ── Open video ─────────────────────────────────────────────────────────
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError(f"Cannot open video: {video_path}")

    fps_native = cap.get(cv2.CAP_PROP_FPS)
    total      = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    w          = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h          = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    print(f"Video: {w}x{h}  native={fps_native:.1f}fps  total_frames={total}")
    print(f"Simulating at {simulate_fps}fps  "
          f"(YOLO-A effective rate ≈ {simulate_fps/10:.1f}fps)\n")

    # ── Reset shared state (safe for repeated calls in tests) ───────────────
    state.mode              = "SPARSE"
    state.rolling_buffer    = {}
    state.safe_clear_ptr    = 0
    state.detected_at_frame = None
    state.stop_event.clear()
    state.signal_s2d.clear()
    state.signal_d2s.clear()
    # Drain queues
    for q in (state.yolo_a_queue, state.yolo_b_queue, state.results_queue):
        while not q.empty():
            try:
                q.get_nowait()
            except Exception:
                break

    # ── Create threads ─────────────────────────────────────────────────────
    t1 = threading.Thread(
        target=thread_frame_dispatcher,
        args=(cap,),
        name="T1-Dispatcher",
        daemon=True,
    )
    t2 = threading.Thread(
        target=thread_yolo_a,
        args=(model_a,),
        name="T2-YOLO-A",
        daemon=True,
    )
    t3 = threading.Thread(
        target=thread_yolo_b,
        args=(model_b,),
        name="T3-YOLO-B",
        daemon=True,
    )
    t4 = threading.Thread(
        target=thread_writer_tracker,
        args=(output_dir, Path(video_path).stem),
        name="T4-WriterTracker",
        daemon=True,
    )

    # ── Start ──────────────────────────────────────────────────────────────
    print("[main] Starting threads ...")
    t1.start()
    t2.start()
    t3.start()
    t4.start()
    print("[main] All threads running. Press Ctrl+C to stop.\n")

    try:
        t1.join()   # wait for video to end (or stop_event)
        t2.join()
        t3.join()
        t4.join()
    except KeyboardInterrupt:
        print("\n[main] KeyboardInterrupt — signalling stop ...")
        state.stop_event.set()
        t1.join(timeout=3)
        t2.join(timeout=3)
        t3.join(timeout=3)
        t4.join(timeout=5)   # give writer extra time to flush
    finally:
        cap.release()
        print("[main] Done.")


# ── CLI ────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Adaptive SPARSE/DENSE YOLO inference pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py --model best.pt --video traffic.avi
  python main.py --model best.pt --video traffic.avi --empty-thresh 3 --simulate-fps 30
        """,
    )
    parser.add_argument(
        "--model", type=str,
        default="../yolo_dataset/runs/train3/weights/best.pt",
        help="Path to YOLO weights",
    )
    parser.add_argument(
        "--video", type=str,
        default="../yolo_dataset/videos/CH_083/20260210_162957_CH83.avi",
        help="Path to input video",
    )
    parser.add_argument(
        "--empty-thresh", type=int, default=EMPTY_COUNT_THRESH,
        help=f"Consecutive YOLO-A zero-detection runs to exit DENSE (default: {EMPTY_COUNT_THRESH})",
    )
    parser.add_argument(
        "--simulate-fps", type=float, default=SIMULATE_FPS,
        help=f"Simulated frame rate for Thread-1 (default: {SIMULATE_FPS})",
    )
    parser.add_argument(
        "--yolo-b-batch", type=int, default=YOLO_B_BATCH_SIZE,
        help=f"YOLO-B batch size (default: {YOLO_B_BATCH_SIZE})",
    )
    parser.add_argument(
        "--output", type=str, default="results",
        help="Directory to save detection CSV (default: results)",
    )

    args = parser.parse_args()

    if not Path(args.model).exists():
        print(f"Error: model not found at {args.model}")
        sys.exit(1)
    if not Path(args.video).exists():
        print(f"Error: video not found at {args.video}")
        sys.exit(1)

    try:
        run_adaptive(
            model_path   = args.model,
            video_path   = args.video,
            empty_thresh = args.empty_thresh,
            simulate_fps = args.simulate_fps,
            yolo_b_batch = args.yolo_b_batch,
            output_dir   = args.output,
        )
    except KeyboardInterrupt:
        print("\nCancelled.")
    except Exception as e:
        import traceback
        print(f"\nError: {e}")
        traceback.print_exc()
        sys.exit(1)

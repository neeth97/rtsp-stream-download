#!/usr/bin/env python3
"""
draw_tracks_images.py  –  Render flushed-track detections onto video frames
                           and save each annotated frame as a JPEG image.

By default only frames that contain at least one detection are saved.
Use --all-frames to save every frame in the video.
If --output is omitted, images are saved to results/output_tracker_images/<video_stem>/.

Usage:
    python draw_tracks_images.py \\
        --tracks results/flushed_tracks_20260219_110434.jsonl \\
        --video  ../yolo_dataset/videos/CH_083/20260210_162957_CH83.avi
    # (output: results/output_tracker_images/20260210_162957_CH83/)

    python draw_tracks_images.py \\
        --tracks results/flushed_tracks_20260219_110434.jsonl \\
        --video  ../yolo_dataset/videos/CH_083/20260210_162957_CH83.avi \\
        --output results/output_tracker_images/20260210_162957_CH83/

    # Save every frame (not just detected ones)
    python draw_tracks_images.py \\
        --tracks results/flushed_tracks_20260219_110434.jsonl \\
        --video  ../yolo_dataset/videos/CH_083/20260210_162957_CH83.avi \\
        --output annotated_frames/ \\
        --all-frames

    # Supply class names explicitly
    python draw_tracks_images.py \\
        --tracks results/flushed_tracks_20260219_110434.jsonl \\
        --video  ../yolo_dataset/videos/CH_083/20260210_162957_CH83.avi \\
        --output annotated_frames/ \\
        --class-names car,truck,bus,motorbike,person,cyclist

    cd /home/ubuntu/new_testing_code/realtime && python3 draw_tracks_images.py \
    --tracks results/flushed_tracks_20260210_162957_CH83_20260219_162544.jsonl \
    --video ../yolo_dataset/videos/CH_083/20260210_162957_CH83.avi \
    --save-video
"""

import argparse
import json
import re
import sys
import time
from collections import defaultdict
from pathlib import Path

import cv2
import numpy as np


# ── PaddleOCR number-plate wrapper ─────────────────────────────────────────
# Logic extracted from VASD/VASD_AI/Metro_VASD_AI/core/ocr.py (use_paddle path)

class PlateOCR:
    """Run PaddleOCR on a cropped number-plate image and return validated text."""

    DEFAULT_DET = "/home/ubuntu/new_testing_code/VASD/VASD_AI/Metro_VASD_AI/models/model_ocr/detection_v1"
    DEFAULT_REC = "/home/ubuntu/new_testing_code/VASD/VASD_AI/Metro_VASD_AI/models/model_ocr/recognition_v3"

    def __init__(self, det_model_dir: str = None, rec_model_dir: str = None):
        from paddleocr import PaddleOCR as _PaddleOCR
        det = det_model_dir or self.DEFAULT_DET
        rec = rec_model_dir or self.DEFAULT_REC
        print(f"Loading PaddleOCR  det={det}  rec={rec}")
        self._ocr = _PaddleOCR(
            use_gpu=True,
            use_angle_cls=True,
            det_model_dir=det,
            rec_model_dir=rec,
            lang="en",
            show_log=False,
        )
        self._valid_states = {
            "AP", "AR", "AS", "BR", "CG", "GA", "GJ", "HR", "HP", "JH",
            "KA", "KL", "MP", "MH", "MN", "ML", "MZ", "NL", "OD", "OR",
            "PB", "RJ", "SK", "TN", "TG", "TS", "TR", "UP", "UK", "WB",
            "AN", "CH", "DN", "DD", "DL", "JK", "LA", "LD", "PY",
        }
        _bh  = r"\d{2}BH\d{4}[A-Z]{2}"
        _new = r"[A-Z]{2}\d{2}[A-Z]{1,3}\d{3,4}"
        _old = r"[A-Z]{2}\d{2}\d{3,4}"
        self._temp_pat = r"T\d{4}[A-Z]{2}\d{3,4}[A-Z]{0,2}"
        self._combined = re.compile(f"{_bh}|{_new}|{_old}|{self._temp_pat}")
        self._invalid  = {"UNKNOWN", "UNKNOW", "NA", "N/A", ""}

    # ------------------------------------------------------------------
    def ocr(self, plate_image: np.ndarray) -> tuple:
        """
        Takes a cropped number-plate image (H×W×3 BGR numpy array).
        Returns (plate_text: str, avg_confidence: float).
        plate_text is '' when nothing is detected.
        """
        h, w = plate_image.shape[:2]
        scale = 640 / max(h, w)
        img_resized = cv2.resize(plate_image, (int(w * scale), int(h * scale)))
        result = self._ocr.ocr(img_resized)

        safe_text = ""
        avg_conf  = 0.0
        if result and result[0]:
            pairs     = [(line[1][0], line[1][1]) for line in result[0]]
            safe_text = "".join(re.sub(r'[\\/*?:"<>|]', "_", t).strip() for t, _ in pairs)
            confs     = [c for _, c in pairs]
            avg_conf  = sum(confs) / len(confs) if confs else 0.0

        return self._extract_plate(safe_text) or "", avg_conf

    # ------------------------------------------------------------------
    def _extract_plate(self, text: str) -> str:
        normalized = str(text).upper().replace(" ", "")
        if normalized in self._invalid:
            return text
        if re.match(self._temp_pat, normalized):
            return text
        # fix duplicated / extra state-code character
        for state in sorted(self._valid_states, key=len, reverse=True):
            if normalized.startswith(state + state):
                normalized = state + normalized[len(state) * 2:]
                break
            if len(normalized) > 3 and normalized[:2] == state:
                if normalized[2].isalpha() and normalized[3].isdigit():
                    normalized = state + normalized[3:]
                    break
        matches = self._combined.findall(normalized)
        if not matches:
            return text
        for m in matches:
            if "BH" in m:
                return m
            if m[:2] in self._valid_states:
                return m
        return matches[0]

# Colour per track_id (cycles through palette so tracks are distinguishable)
TRACK_PALETTE = [
    (  0, 255,   0), (255,  80,  80), (  0, 180, 255), (255, 200,   0),
    (180,   0, 255), (  0, 255, 180), (255, 120,   0), ( 80, 255,  80),
    (255,   0, 160), (  0, 200, 200), (160, 255,   0), (200,  80, 255),
]


# ── helpers ────────────────────────────────────────────────────────────────

def _lerp_bbox_conf(bbox_a: list, conf_a: float, bbox_b: list, conf_b: float, t: float) -> tuple:
    """Linear interpolation between two bboxes and confidences. t in [0, 1]."""
    bbox = [(1 - t) * a + t * b for a, b in zip(bbox_a, bbox_b)]
    conf = (1 - t) * conf_a + t * conf_b
    return bbox, conf


def _interpolate_track_history(history: list, key_frame: str = "frame_id", key_bbox: str = "bbox", key_conf: str = "confidence") -> list:
    """
    Given a sorted list of {frame_id, bbox, confidence}, return a list with
    interpolated entries for every frame between consecutive detections.
    """
    if not history:
        return []
    sorted_hist = sorted(history, key=lambda x: x[key_frame])
    out = []
    for i, det in enumerate(sorted_hist):
        out.append({**det})
        if i + 1 >= len(sorted_hist):
            break
        next_det = sorted_hist[i + 1]
        f_a = det[key_frame]
        f_b = next_det[key_frame]
        if f_b <= f_a + 1:
            continue
        bbox_a = det[key_bbox]
        conf_a = det[key_conf]
        bbox_b = next_det[key_bbox]
        conf_b = next_det[key_conf]
        for f in range(f_a + 1, f_b):
            t = (f - f_a) / (f_b - f_a)
            bbox, conf = _lerp_bbox_conf(bbox_a, conf_a, bbox_b, conf_b, t)
            out.append({key_frame: f, key_bbox: bbox, key_conf: conf, **{k: v for k, v in det.items() if k not in (key_frame, key_bbox, key_conf)}})
    return out


def load_tracks(jsonl_path: str, interpolate: bool = True) -> tuple:
    """
    Parse a flushed-tracks JSONL file. When interpolate=True, fill in-between
    frames with linearly interpolated bbox/confidence so tracks appear continuous.

    Returns:
        frame_index:       {frame_id -> [{'track_id', 'class_id', 'bbox', 'confidence'}]}
        plate_frame_index: {frame_id -> [{'track_id', 'bbox', 'confidence'}]}
    """
    tracks_vehicle = {}
    tracks_plate   = {}
    with open(jsonl_path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            track = json.loads(line)
            tid = track["track_id"]
            cid = track["class_id"]
            hist = [{"frame_id": d["frame_id"], "bbox": d["bbox"], "confidence": d["confidence"]} for d in track["history"]]
            tracks_vehicle[tid] = (cid, hist)
            plate_hist = [{"frame_id": p["frame_id"], "bbox": p["bbox"], "confidence": p["confidence"]} for p in track.get("plate_history", [])]
            if plate_hist:
                tracks_plate[tid] = plate_hist

    frame_index       = defaultdict(list)
    plate_frame_index = defaultdict(list)

    for tid, (cid, hist) in tracks_vehicle.items():
        if interpolate and len(hist) > 0:
            hist = _interpolate_track_history(hist, "frame_id", "bbox", "confidence")
        for det in hist:
            frame_index[det["frame_id"]].append({
                "track_id":   tid,
                "class_id":   cid,
                "bbox":       det["bbox"],
                "confidence": det["confidence"],
            })

    for tid, hist in tracks_plate.items():
        if interpolate and len(hist) > 0:
            hist = _interpolate_track_history(hist, "frame_id", "bbox", "confidence")
        for det in hist:
            plate_frame_index[det["frame_id"]].append({
                "track_id":   tid,
                "bbox":       det["bbox"],
                "confidence": det["confidence"],
            })

    return frame_index, plate_frame_index


def draw_detections(frame: np.ndarray, dets: list, plates: list,
                    class_names: dict, ocr_results: dict = None,
                    current_frame_id: int = 0) -> np.ndarray:
    """Draw vehicle bounding boxes + labels, and plate bboxes in the same track colour.

    ocr_results: optional {track_id -> (plate_text, conf, crop_img, best_frame_id)}
    For every track with OCR results, a card is drawn in the top-right corner
    (stacked top-to-bottom) showing: plate crop | OCR text | best frame | current frame.
    """
    out = frame.copy()
    h, w = out.shape[:2]

    # ── Vehicle boxes ────────────────────────────────────────────────────────
    for det in dets:
        x1, y1, x2, y2 = map(int, det["bbox"])
        tid   = det["track_id"]
        cid   = det["class_id"]
        conf  = det["confidence"]
        color = TRACK_PALETTE[tid % len(TRACK_PALETTE)]

        cv2.rectangle(out, (x1, y1), (x2, y2), color, 4)

        cls_name = class_names.get(cid, f"class_{cid}")
        label    = f"{cls_name} #{tid} {conf:.2f}"

        font       = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 2.0
        thickness  = 4
        (lw, lh), baseline = cv2.getTextSize(label, font, font_scale, thickness)

        ty = max(y1, lh + baseline + 8)
        cv2.rectangle(out, (x1, ty - lh - baseline - 8), (x1 + lw + 4, ty), color, -1)
        cv2.putText(out, label, (x1 + 2, ty - baseline - 4),
                    font, font_scale, (0, 0, 0), thickness, cv2.LINE_AA)

    # ── Number-plate boxes (same colour as parent track, thinner border) ─────
    for plate in plates:
        px1, py1, px2, py2 = map(int, plate["bbox"])
        tid   = plate["track_id"]
        color = TRACK_PALETTE[tid % len(TRACK_PALETTE)]

        cv2.rectangle(out, (px1, py1), (px2, py2), color, 3)

        if ocr_results and tid in ocr_results and ocr_results[tid][0]:
            label = f"{ocr_results[tid][0]} ({ocr_results[tid][1]:.2f})"
        else:
            label = f"#{tid}"
        font       = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 1.6
        thickness  = 3
        (lw, lh), baseline = cv2.getTextSize(label, font, font_scale, thickness)

        ty = max(py1, lh + baseline + 6)
        cv2.rectangle(out, (px1, ty - lh - baseline - 6), (px1 + lw + 4, ty), color, -1)
        cv2.putText(out, label, (px1 + 2, ty - baseline - 2),
                    font, font_scale, (0, 0, 0), thickness, cv2.LINE_AA)

    # ── Top-right panel: one card per track with OCR result ──────────────────
    if ocr_results:
        font      = cv2.FONT_HERSHEY_SIMPLEX
        PAD       = 10
        SCALE     = 2.5
        TXT_SCALE = 1.4
        TXT_THICK = 2
        cursor_y  = PAD

        for tid, (text, conf, crop_img, best_fid) in sorted(ocr_results.items()):
            if cursor_y >= h - 20:
                break

            color       = TRACK_PALETTE[tid % len(TRACK_PALETTE)]
            plate_label = text if text else "unknown"

            # Scale the plate crop
            ph, pw = crop_img.shape[:2]
            big    = cv2.resize(crop_img, (int(pw * SCALE), int(ph * SCALE)),
                                interpolation=cv2.INTER_LINEAR)
            bh, bw = big.shape[:2]

            # Measure text lines
            lbl_lines = [plate_label,
                         f"Best frame: {best_fid}",
                         f"Frame: {current_frame_id}"]
            line_sizes = [cv2.getTextSize(l, font, TXT_SCALE, TXT_THICK) for l in lbl_lines]
            txt_w      = max(s[0][0] for s in line_sizes)

            card_w = max(bw, txt_w + PAD * 2)
            x0     = w - card_w - PAD   # right-aligned

            # Paste plate crop
            if cursor_y + bh > h:
                break
            x_crop = x0 + (card_w - bw) // 2
            out[cursor_y:cursor_y + bh, x_crop:x_crop + bw] = big
            cv2.rectangle(out, (x_crop, cursor_y), (x_crop + bw, cursor_y + bh), color, 3)
            cursor_y += bh + PAD

            # Draw text lines with coloured background
            for line, ((lw, lh), bl) in zip(lbl_lines, line_sizes):
                box_h = lh + bl + PAD * 2
                if cursor_y + box_h > h:
                    break
                cv2.rectangle(out, (x0, cursor_y),
                              (x0 + card_w, cursor_y + box_h), color, -1)
                cv2.putText(out, line,
                            (x0 + PAD, cursor_y + PAD + lh),
                            font, TXT_SCALE, (0, 0, 0), TXT_THICK, cv2.LINE_AA)
                cursor_y += box_h + 2

            cursor_y += PAD * 2   # gap between cards

    return out


# ── main logic ─────────────────────────────────────────────────────────────

def run(tracks_path: str, video_path: str, output_dir: str,
        class_names: dict, all_frames: bool, interpolate: bool = True,
        det_model: str = None, rec_model: str = None, skip_ocr: bool = False,
        save_video: bool = False) -> None:
    """
    Read every frame from video_path, overlay detections from frame_index,
    and save each result as a JPEG in output_dir.

    If skip_ocr is False (default), PlateOCR is initialised and run once per
    tracked plate crop; the recognised text is drawn on the plate box and
    printed as a summary at the end.
    """
    frame_index, plate_frame_index = load_tracks(tracks_path, interpolate=interpolate)
    total_dets  = sum(len(v) for v in frame_index.values())
    total_plates = sum(len(v) for v in plate_frame_index.values())
    detected_frame_ids = set(frame_index.keys())
    print(f"Loaded {total_dets} detections and {total_plates} plate detections "
          f"across {len(detected_frame_ids)} frames from '{tracks_path}'")

    # Initialise OCR once (heavy model load – done before video loop)
    plate_ocr      = None
    track_ocr_results = {}   # {track_id -> (plate_text, conf, crop_img, best_frame_id)}
    if not skip_ocr and total_plates > 0:
        try:
            plate_ocr = PlateOCR(det_model, rec_model)
        except Exception as e:
            print(f"[WARN] Could not initialise PlateOCR: {e}  (continuing without OCR)",
                  file=sys.stderr)

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Error: cannot open video '{video_path}'", file=sys.stderr)
        sys.exit(1)

    total  = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    width  = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps    = cap.get(cv2.CAP_PROP_FPS) or 25.0

    # ── Profiling accumulators (all in seconds) ───────────────────────────────
    prof = {
        "best_frame_pick": 0.0,
        "ocr_inference":   0.0,
        "frame_read":      0.0,
        "draw_annotate":   0.0,
        "frame_write":     0.0,
    }

    # ── Pre-select best OCR frame per track ──────────────────────────────────
    # Best frame = plate ymax is largest (plate closest / biggest in frame)
    # but ymax must not exceed (height - 100) to avoid cut-off plates.
    _t = time.time()
    ymax_limit = height - 100
    best_ocr_frame = {}   # {track_id -> frame_id}
    if plate_ocr:
        best_ymax = {}    # {track_id -> best ymax seen so far}
        for fid, plate_list in plate_frame_index.items():
            for plate in plate_list:
                tid  = plate["track_id"]
                ymax = plate["bbox"][3]
                if ymax > ymax_limit:
                    continue
                if tid not in best_ymax or ymax > best_ymax[tid]:
                    best_ymax[tid]    = ymax
                    best_ocr_frame[tid] = fid
        print(f"Best OCR frame selected for {len(best_ocr_frame)} track(s)  "
              f"(ymax_limit={ymax_limit}px)")
    prof["best_frame_pick"] += time.time() - _t

    # ── Last frame per track (for panel visibility window) ────────────────────
    track_last_frame = {}   # {tid -> last frame_id in frame_index}
    for fid, dets in frame_index.items():
        for det in dets:
            tid = det["track_id"]
            if tid not in track_last_frame or fid > track_last_frame[tid]:
                track_last_frame[tid] = fid

    # ── Output directories ────────────────────────────────────────────────────
    out_path      = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    selected_path = out_path.parent.parent / "output_selected_frames_images" / out_path.name
    selected_path.mkdir(parents=True, exist_ok=True)

    last_frame_to_process = (max(detected_frame_ids) + 10) if detected_frame_ids else 0

    # ── VideoWriter setup (optional) ──────────────────────────────────────────
    writer         = None
    video_path_out = None
    if save_video:
        video_dir      = out_path.parent.parent / "output_tracker_video"
        video_dir.mkdir(parents=True, exist_ok=True)
        video_path_out = video_dir / f"{Path(video_path).stem}.mp4"
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(video_path_out), fourcc, fps, (width, height))
        if not writer.isOpened():
            print(f"[WARN] Could not open VideoWriter for '{video_path_out}'",
                  file=sys.stderr)
            writer = None

    print(f"Video : {width}x{height}  {fps:.1f} fps  {total} frames")
    print(f"Output: {out_path}/")
    if writer is not None:
        print(f"Video output: {video_path_out}")
    print("Processing ...")

    frame_id             = 1
    saved                = 0
    ocr_fired_this_frame = set()

    while True:
        _t = time.time()
        ret, frame = cap.read()
        prof["frame_read"] += time.time() - _t
        if not ret:
            break

        # ── Inline OCR: run the moment we hit each track's best frame ─────────
        if plate_ocr:
            ocr_fired_this_frame.clear()
            for tid, best_fid in best_ocr_frame.items():
                if frame_id == best_fid and tid not in track_ocr_results:
                    plates_at = [p for p in plate_frame_index.get(frame_id, [])
                                 if p["track_id"] == tid]
                    if plates_at:
                        px1, py1, px2, py2 = map(int, plates_at[0]["bbox"])
                        crop = frame[py1:py2, px1:px2]
                        if crop.size > 0:
                            try:
                                _t = time.time()
                                text, conf = plate_ocr.ocr(crop)
                                prof["ocr_inference"] += time.time() - _t
                                track_ocr_results[tid] = (text, conf, crop.copy(), frame_id)
                                print(f"  OCR  track #{tid}  →  {text or '(no text)'}  "
                                      f"(conf {conf:.3f})")
                                ocr_fired_this_frame.add(tid)
                            except Exception as e:
                                print(f"  [WARN] OCR failed for track #{tid}: {e}",
                                      file=sys.stderr)

        # ── Determine which tracks show panel this frame ──────────────────────
        panel_ocr = {
            tid: track_ocr_results[tid]
            for tid in track_ocr_results
            if best_ocr_frame.get(tid, 0) <= frame_id
            <= track_last_frame.get(tid, best_ocr_frame.get(tid, 0)) + 10
        }

        dets   = frame_index.get(frame_id, [])
        plates = plate_frame_index.get(frame_id, [])

        if dets or panel_ocr or all_frames:
            _t = time.time()
            annotated = draw_detections(frame, dets, plates, class_names,
                                        panel_ocr, frame_id)
            prof["draw_annotate"] += time.time() - _t

            _t = time.time()
            cv2.imwrite(str(out_path / f"frame_{frame_id:06d}.jpg"), annotated,
                        [cv2.IMWRITE_JPEG_QUALITY, 92])
            # Also save to selected_frames for any track whose OCR just fired
            for tid in ocr_fired_this_frame:
                plate_label = track_ocr_results[tid][0] or "unknown"
                sel_fname = selected_path / f"track{tid:04d}_frame{frame_id:06d}_{plate_label}.jpg"
                cv2.imwrite(str(sel_fname), annotated, [cv2.IMWRITE_JPEG_QUALITY, 92])
            prof["frame_write"] += time.time() - _t
            saved += 1

            if saved % 50 == 0:
                print(f"  saved {saved}  (last: frame_{frame_id:06d}.jpg)")
        else:
            annotated = frame   # no annotations — use raw frame for video

        # Write every frame to video (continuous, no gaps)
        if writer is not None:
            writer.write(annotated)

        frame_id += 1

        # Early exit when NOT writing video (video needs every frame to the end)
        if not save_video and not all_frames and detected_frame_ids \
                and frame_id > last_frame_to_process:
            break

    cap.release()
    if writer is not None:
        writer.release()
        print(f"Video saved → '{video_path_out}'")
    print(f"\nDone.  {saved} image(s) saved to '{out_path}/'")

    if track_ocr_results:
        print("\n── OCR Results ──────────────────────────────")
        for tid, (text, conf, _, fid) in sorted(track_ocr_results.items()):
            print(f"  Track #{tid:>4d}  →  {text:<12s}  conf {conf:.3f}  (frame {fid})")
        print("─────────────────────────────────────────────")

    total_prof = sum(prof.values())
    print("\n── Timing Profile ───────────────────────────")
    labels = {
        "best_frame_pick": "Best-frame selection",
        "ocr_inference":   "PaddleOCR inference",
        "frame_read":      "Video frame read (cap.read)",
        "draw_annotate":   "Draw annotations",
        "frame_write":     "Write annotated JPEGs",
    }
    for key, label in labels.items():
        secs = prof[key]
        pct  = secs / total_prof * 100 if total_prof else 0
        print(f"  {label:<30s}  {secs:6.2f}s  ({pct:4.1f}%)")
    print(f"  {'─'*44}")
    print(f"  {'Total accounted':<30s}  {total_prof:6.2f}s")
    print("─────────────────────────────────────────────")


# ── CLI ────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Overlay flushed-track detections onto video frames and save as images.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Save only frames that contain detections (default)
  python draw_tracks_images.py \\
      --tracks results/flushed_tracks_20260219_110434.jsonl \\
      --video  ../yolo_dataset/videos/CH_083/20260210_162957_CH83.avi \\
      --output annotated_frames/

  # Save every frame in the video
  python draw_tracks_images.py \\
      --tracks results/flushed_tracks_20260219_110434.jsonl \\
      --video  ../yolo_dataset/videos/CH_083/20260210_162957_CH83.avi \\
      --output annotated_frames/ \\
      --all-frames

  # Custom class names
  python draw_tracks_images.py \\
      --tracks results/flushed_tracks_20260219_110434.jsonl \\
      --video  ../yolo_dataset/videos/CH_083/20260210_162957_CH83.avi \\
      --output annotated_frames/ \\
      --class-names car,truck,bus,motorbike,person,cyclist
        """,
    )
    parser.add_argument("--tracks", required=True,
                        help="Path to flushed_tracks_*.jsonl file")
    parser.add_argument("--video",  required=True,
                        help="Path to input video file")
    parser.add_argument("--output", default=None,
                        help="Output directory for annotated JPEG images "
                             "(default: results/output_tracker_images/<video_stem>/)")
    parser.add_argument("--all-frames", action="store_true",
                        help="Save every frame, not just frames with detections")
    parser.add_argument("--class-names", default="",
                        help="Comma-separated class names ordered by id. "
                             "Falls back to auto-detection from best.pt, "
                             "then class_0, class_1, … if omitted.")
    parser.add_argument("--no-interpolate", action="store_true",
                        help="Do not interpolate track bboxes between consecutive detections")
    parser.add_argument("--det-model", default=None,
                        help="Path to PaddleOCR detection model dir "
                             f"(default: {PlateOCR.DEFAULT_DET})")
    parser.add_argument("--rec-model", default=None,
                        help="Path to PaddleOCR recognition model dir "
                             f"(default: {PlateOCR.DEFAULT_REC})")
    parser.add_argument("--no-ocr", action="store_true",
                        help="Disable PaddleOCR inference (faster, no plate text)")
    parser.add_argument("--save-video", action="store_true",
                        help="Write all frames to an annotated MP4 "
                             "(results/output_tracker_video/<stem>.mp4)")

    args = parser.parse_args()

    # Build class-name dict
    if args.class_names.strip():
        names_list  = [n.strip() for n in args.class_names.split(",")]
        class_names = {i: n for i, n in enumerate(names_list)}
    else:
        try:
            from ultralytics import YOLO
            import glob, os
            candidates = glob.glob(
                os.path.join(os.path.dirname(__file__), "..", "yolo_dataset",
                             "runs", "**", "best.pt"), recursive=True)
            if candidates:
                m = YOLO(candidates[0])
                class_names = m.names
                print(f"Class names from model: {class_names}")
            else:
                raise FileNotFoundError
        except Exception:
            class_names = {}

    if not Path(args.tracks).exists():
        print(f"Error: tracks file not found: {args.tracks}", file=sys.stderr)
        sys.exit(1)
    if not Path(args.video).exists():
        print(f"Error: video file not found: {args.video}", file=sys.stderr)
        sys.exit(1)

    if args.output is None:
        video_stem = Path(args.video).stem
        args.output = str(Path("results") / "output_tracker_images" / video_stem)

    run(
        tracks_path=args.tracks,
        video_path=args.video,
        output_dir=args.output,
        class_names=class_names,
        all_frames=args.all_frames,
        interpolate=not args.no_interpolate,
        det_model=args.det_model,
        rec_model=args.rec_model,
        skip_ocr=args.no_ocr,
        save_video=args.save_video,
    )

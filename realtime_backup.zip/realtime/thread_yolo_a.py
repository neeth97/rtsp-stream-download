# ─────────────────────────────────────────────
# thread_yolo_a.py  –  Thread-2
# Lightweight YOLO inference on every SPARSE_INTERVAL-th frame.
# Sole controller of SPARSE↔DENSE state transitions.
# ─────────────────────────────────────────────

import time
import queue
import sys
import os
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from inference_video_batch import predict_frames_batch

import shared_state as state
from config import EMPTY_COUNT_THRESH


def _extract_detections(result):
    """Extract boxes, classes, confidences from a YOLO result object."""
    if result is None or result.boxes is None or len(result.boxes) == 0:
        return [], [], []
    return (
        result.boxes.xyxy.cpu().numpy(),
        result.boxes.cls.cpu().numpy(),
        result.boxes.conf.cpu().numpy(),
    )


def thread_yolo_a(model_a) -> None:
    """
    Thread-2 entry point.

    Runs YOLO-A on frames from yolo_a_queue.
    - In SPARSE mode: one detection  → signals SPARSE→DENSE
    - In DENSE  mode: N consecutive zero-detection runs → signals DENSE→SPARSE

    Args:
        model_a: loaded YOLO model instance (lightweight)
    """
    consecutive_empty = 0   # counts consecutive zero-detection results in DENSE mode

    while not state.stop_event.is_set():
        try:
            frame_id, frame = state.yolo_a_queue.get(timeout=1.0)
        except queue.Empty:
            continue

        # Run inference (single frame passed as a batch of 1)
        t0         = time.time()
        results    = predict_frames_batch(model_a, [frame])
        infer_ms   = (time.time() - t0) * 1000
        det_count  = sum(
            len(r.boxes) for r in results if r is not None and r.boxes is not None
        )

        with state.mode_lock:
            current_mode = state.mode

        # Extract and push detections into results_queue
        result       = results[0] if results else None
        boxes, classes, confidences = _extract_detections(result)
        try:
            state.results_queue.put_nowait({
                'frame_id'    : frame_id,
                'source'      : 'YOLO-A',
                'det_count'   : det_count,
                'boxes'       : boxes,
                'classes'     : classes,
                'confidences' : confidences,
                'infer_ms'    : infer_ms,
            })
        except queue.Full:
            pass   # drop silently if consumer is not keeping up

        print(f"[YOLO-A] frame={frame_id:5d}  mode={current_mode}  "
              f"detections={det_count}  infer={infer_ms:.1f}ms")

        # ── SPARSE mode logic ──────────────────────────────────────────────
        if current_mode == "SPARSE":
            if det_count >= 1:
                consecutive_empty = 0
                with state.mode_lock:
                    state.detected_at_frame = frame_id
                state.signal_s2d.set()   # notify Thread-1 to switch to DENSE

        # ── DENSE mode logic ───────────────────────────────────────────────
        elif current_mode == "DENSE":
            if det_count == 0:
                consecutive_empty += 1
                print(f"[YOLO-A] consecutive empty={consecutive_empty}/{EMPTY_COUNT_THRESH}")
                if consecutive_empty >= EMPTY_COUNT_THRESH:
                    consecutive_empty = 0
                    state.signal_d2s.set()   # notify Thread-1 to switch to SPARSE
            else:
                consecutive_empty = 0        # reset counter on any detection

    # Drain remaining frames on shutdown
    remaining = 0
    while True:
        try:
            state.yolo_a_queue.get_nowait()
            remaining += 1
        except Exception:
            break
    if remaining:
        print(f"[YOLO-A] Drained {remaining} remaining frames on shutdown.")

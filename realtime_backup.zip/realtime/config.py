# ─────────────────────────────────────────────
# config.py  –  all tunable constants
# ─────────────────────────────────────────────

# Frame sampling intervals
SPARSE_INTERVAL    = 10   # YOLO-A fires every Nth frame (both modes)
DENSE_INTERVAL     = 2    # YOLO-B fires every Nth frame (dense mode only)

# State-transition threshold
EMPTY_COUNT_THRESH = 2    # consecutive YOLO-A zero-detection checks to exit DENSE

# YOLO-B batching
YOLO_B_BATCH_SIZE  = 4    # accumulate this many frames before running YOLO-B

# Rolling buffer
BUFFER_SIZE        = 30   # must be >= SPARSE_INTERVAL to support backfill

# Real-time simulation
SIMULATE_FPS       = 25   # Thread-1 targets this frame rate via adaptive sleep

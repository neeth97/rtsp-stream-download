# ─────────────────────────────────────────────
# thread_dispatcher.py  –  Thread-1
# Reads frames, manages rolling buffer, routes to YOLO-A / YOLO-B queues.
# Handles SPARSE↔DENSE transitions triggered by YOLO-A signals.
# ─────────────────────────────────────────────

import time
import shared_state as state
from config import (
    SPARSE_INTERVAL,
    DENSE_INTERVAL,
    SIMULATE_FPS,
)


def _handle_signals(frame_id: int) -> None:
    """
    Check transition signals set by YOLO-A and act on them.
    Must be called from Thread-1 only.
    """
    # ── SPARSE → DENSE ────────────────────────────────────────────────────────
    if state.signal_s2d.is_set():
        state.signal_s2d.clear()

        with state.mode_lock:
            T = state.detected_at_frame
            state.mode = "DENSE"

        # Backfill: push frames that were missed while in SPARSE mode
        # T-10, T-8, T-6, T-4, T-2, T  (includes the detected frame itself)
        with state.buffer_lock:
            for offset in [10, 8, 6, 4, 2, 0]:
                fid = T - offset
                if fid > 0 and fid in state.rolling_buffer:
                    state.yolo_b_queue.put((fid, state.rolling_buffer[fid].copy()))

        # Frontfill: catch up from T+DENSE_INTERVAL to current frame_id
        fid = T + DENSE_INTERVAL
        while fid <= frame_id:
            with state.buffer_lock:
                if fid in state.rolling_buffer:
                    state.yolo_b_queue.put((fid, state.rolling_buffer[fid].copy()))
            fid += DENSE_INTERVAL

        # Frames before T are now safe to evict
        with state.buffer_lock:
            state.safe_clear_ptr = T

        print(f"[T1] SPARSE → DENSE  (detected at frame {T}, "
              f"backfilled up to frame {frame_id})")

    # ── DENSE → SPARSE ────────────────────────────────────────────────────────
    if state.signal_d2s.is_set():
        state.signal_d2s.clear()
        with state.mode_lock:
            state.mode = "SPARSE"
        # Thread-1 simply stops feeding yolo_b_queue; YOLO-B drains naturally.
        print(f"[T1] DENSE → SPARSE  (at frame {frame_id})")


def thread_frame_dispatcher(cap) -> None:
    """
    Thread-1 entry point.

    Args:
        cap: cv2.VideoCapture instance (opened by main.py)
    """
    frame_id      = 0
    target_period = 1.0 / SIMULATE_FPS   # seconds per frame budget

    while not state.stop_event.is_set():
        frame_start = time.time()         # wall-clock anchor for adaptive sleep

        # ── Step 1: read frame ─────────────────────────────────────────────
        t0 = time.time()
        ret, frame = cap.read()
        t_read = time.time() - t0

        if not ret:
            print("[T1] Video ended — stopping all threads.")
            state.stop_event.set()
            break

        frame_id += 1

        # ── Step 2: store in rolling buffer + evict stale frames ───────────
        t0 = time.time()
        with state.buffer_lock:
            state.rolling_buffer[frame_id] = frame
            stale = [k for k in state.rolling_buffer if k < state.safe_clear_ptr]
            for k in stale:
                del state.rolling_buffer[k]
        t_buffer = time.time() - t0

        # ── Step 3: handle transition signals (backfill / frontfill) ───────
        t0 = time.time()
        _handle_signals(frame_id)
        t_signals = time.time() - t0

        # ── Step 4: route frame to correct queue(s) ─────────────────────────
        t0 = time.time()
        with state.mode_lock:
            current_mode = state.mode

        if current_mode == "SPARSE":
            if frame_id % SPARSE_INTERVAL == 0:
                state.yolo_a_queue.put((frame_id, frame.copy()))

        elif current_mode == "DENSE":
            if frame_id % DENSE_INTERVAL == 0:
                state.yolo_b_queue.put((frame_id, frame.copy()))
            if frame_id % SPARSE_INTERVAL == 0:
                # YOLO-A must keep running in DENSE to detect empty → exit
                state.yolo_a_queue.put((frame_id, frame.copy()))
        t_route = time.time() - t0

        # ── Adaptive sleep: consume only the remaining frame budget ─────────
        elapsed   = time.time() - frame_start
        sleep_for = target_period - elapsed

        if sleep_for > 0:
            time.sleep(sleep_for)
        else:
            print(
                f"[T1] WARNING frame={frame_id} overran budget by "
                f"{abs(sleep_for) * 1000:.2f}ms  "
                f"(read={t_read*1000:.1f}ms  buffer={t_buffer*1000:.1f}ms  "
                f"signals={t_signals*1000:.1f}ms  route={t_route*1000:.1f}ms)"
            )
